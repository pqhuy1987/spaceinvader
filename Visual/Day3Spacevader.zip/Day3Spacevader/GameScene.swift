//
//  GameScene.swift
//  Day3Spacevader
//
//  Created by iD Student on 6/22/16.
//  Copyright (c) 2016 iD Student. All rights reserved.
//

import SpriteKit

struct Bodytype {
    static let None: UInt32 = 0
    static let Meteor: UInt32 = 1
    static let Bullet: UInt32 = 2
    static let Hero: UInt32 = 4
}


class GameScene: SKScene, SKPhysicsContactDelegate {
    
    let hero = SKSpriteNode(imageNamed: "Spaceship")
    let heroSpeed: CGFloat = 100.0
    var meteorScore = 0
    var scoreLabel = SKLabelNode(fontNamed: "Arial")
    
    override func didMoveToView(view: SKView) {
        backgroundColor = SKColor.blackColor()
        let xCoord = size.width * 0.5
        let yCoord = size.height * 0.5
        
        hero.size.height = 50
        hero.size.width = 50
        
        hero.position = CGPoint(x: xCoord, y: yCoord)
        
        hero.physicsBody = SKPhysicsBody(rectangleOfSize: hero.size)
        hero.physicsBody?.dynamic = true
        hero.physicsBody?.categoryBitMask = Bodytype.Hero
        hero.physicsBody?.contactTestBitMask = Bodytype.Meteor
        hero.physicsBody?.collisionBitMask = 0
        addChild(hero)
        
        
        let swipeUp: UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: ("swipedUp:"))
        
        swipeUp.direction = .Up
        view.addGestureRecognizer(swipeUp)
        
        
        
        let swipeDown: UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: ("swipedDown:"))
        
        swipeDown.direction = .Down
        view.addGestureRecognizer(swipeDown)
        
        
        let swipeRight: UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: ("swipedRight:"))
        
        swipeRight.direction = .Right
        view.addGestureRecognizer(swipeRight)
        
        
        let swipeLeft: UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: ("swipedLeft:"))
        swipeLeft.direction = .Left
        view.addGestureRecognizer(swipeLeft)
        
        addMeteor()
        runAction(SKAction.repeatActionForever(SKAction.sequence([SKAction.runBlock(addMeteor), SKAction.waitForDuration(1.0)])))
        
        physicsWorld.gravity = CGVectorMake(0,0)
        physicsWorld.contactDelegate = self
        
        scoreLabel.fontColor = UIColor.whiteColor()
        scoreLabel.fontSize = 50
        scoreLabel.position = CGPointMake(self.size.width/2, self.size.height-50)
        scoreLabel.text = "0"
        addChild(scoreLabel)
    }
    
    func random() -> CGFloat {
        
        return CGFloat(Float(arc4random()) / Float(UINT32_MAX))
        
    }
    
    func addMeteor() {
        var meteor: Enemy
        
        meteor = Enemy(imageNamed: "MeteorLeft")
        
        meteor.size.height = 35
        meteor.size.width = 50
        
        let randomY = random() * ((size.height - meteor.size.height/2)-meteor.size.height/2) + meteor.size.height/2
        meteor.position = CGPoint(x: size.width + meteor.size.width/2, y: randomY)
        
        addChild(meteor)
        
        var moveMeteor: SKAction
        moveMeteor = SKAction.moveTo(CGPoint(x: -meteor.size.width, y: randomY), duration: NSTimeInterval(5.0) )
        meteor.runAction(SKAction.sequence([moveMeteor, SKAction.removeFromParent()]))
        
        meteor.physicsBody = SKPhysicsBody(rectangleOfSize: meteor.size)
        meteor.physicsBody?.dynamic = true
        meteor.physicsBody?.categoryBitMask = Bodytype.Meteor
        meteor.physicsBody?.contactTestBitMask = Bodytype.Bullet
        meteor.physicsBody?.collisionBitMask = 0

    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
       /* Called when a touch begins */
        
       
    }
   
    override func update(currentTime: CFTimeInterval) {
        /* Called before each frame is rendered */
    }
    
    override func touchesEnded(touches: Set<UITouch>, withEvent event: UIEvent?){
        let bullet = SKSpriteNode()
        
        bullet.color = UIColor.redColor()
        bullet.size  = CGSize(width: 5,height: 5)
        bullet.position = CGPointMake(hero.position.x, hero.position.y)
        
        bullet.physicsBody = SKPhysicsBody(circleOfRadius: bullet.size.width/2)
        bullet.physicsBody?.dynamic = true
        bullet.physicsBody?.categoryBitMask = Bodytype.Bullet
        bullet.physicsBody?.contactTestBitMask = Bodytype.Meteor
        bullet.physicsBody?.collisionBitMask = 0
        bullet.physicsBody?.usesPreciseCollisionDetection = true
        
        addChild(bullet)
        
        guard let touch = touches.first else {return }
        
        let touchLocation = touch.locationInNode(self)
        
        
        
        let vector = CGVectorMake(-(hero.position.x-touchLocation.x), -(hero.position.y-touchLocation.y))
        
        let projectileAction = SKAction.sequence([
            SKAction.repeatAction(SKAction.moveBy(vector, duration: 0.5), count: 10),
            SKAction.waitForDuration(0.5),
            SKAction.removeFromParent()
            ])
        
        
        
        bullet.runAction(projectileAction)
        
    }
    
    
    func swipedUp(sender:UISwipeGestureRecognizer){
        var actionMove: SKAction
        
        
        
        if (hero.position.y + heroSpeed >= size.height){
            actionMove = SKAction.moveTo(CGPoint(x: hero.position.x, y: size.height - hero.size.height/2), duration: NSTimeInterval(0.5))
        }
        else {
            actionMove = SKAction.moveTo(CGPoint(x: hero.position.x, y: hero.position.y + heroSpeed), duration: NSTimeInterval(0.5))

        }
        
        
        
        
        hero.runAction(actionMove)
        print("Up")
    }
    
    func swipedDown(sender:UISwipeGestureRecognizer){
        var actionMove: SKAction
        //actionMove = SKAction.moveTo(CGPoint(x: hero.position.x, y: hero.position.y - heroSpeed), duration: NSTimeInterval (0.5))
        
        
        if (hero.position.y - heroSpeed <= 0){
            actionMove = SKAction.moveTo(CGPoint(x: hero.position.x, y: size.height + hero.size.height/2), duration: NSTimeInterval(0.5))
        }
        else {
            actionMove = SKAction.moveTo(CGPoint(x: hero.position.x, y: hero.position.y - heroSpeed), duration: NSTimeInterval(0.5))
            
        }
        
        hero.runAction(actionMove)

        print("Down")
    }
    
    func swipedRight(sender:UISwipeGestureRecognizer){
        var actionMove: SKAction
//        actionMove = SKAction.moveTo(CGPoint(x: hero.position.x + heroSpeed, y: hero.position.y), duration: NSTimeInterval (0.5))
        
        if (hero.position.x + heroSpeed >= size.width){
            actionMove = SKAction.moveTo(CGPoint(x: size.width - hero.size.width/2, y: hero.position.y), duration: NSTimeInterval(0.5))
        }
        else {
            actionMove = SKAction.moveTo(CGPoint(x: hero.position.x + heroSpeed, y: hero.position.y), duration: NSTimeInterval(0.5))
            
        }
        
        
        hero.runAction(actionMove)

        print("Right")
    }
    
    func swipedLeft(sender:UISwipeGestureRecognizer){
        var actionMove : SKAction
        actionMove = SKAction.moveTo(CGPoint(x: hero.position.x - heroSpeed, y: hero.position.y ), duration: NSTimeInterval (0.5))
        
        
        if (hero.position.x - heroSpeed <= 0){
            actionMove = SKAction.moveTo(CGPoint(x: hero.size.width/2, y: hero.position.y), duration: NSTimeInterval(0.5))
        }
        else {
            actionMove = SKAction.moveTo(CGPoint(x: hero.position.x - heroSpeed, y: hero.position.y), duration: NSTimeInterval(0.5))
            
        }
        
        
        hero.runAction(actionMove)

        
        
        print("Left")
    }
    
    func bulletHitMeteor(bullet: SKSpriteNode, meteor: Enemy){
        
        bullet.removeFromParent()
        

        meteor.removeFromParent()
        
        meteorScore++
        scoreLabel.text = String(meteorScore)
        
        explodeMeteor(meteor)

    }
    
    func heroHitMeteor(player: SKSpriteNode, meteor: SKSpriteNode){
        
        removeAllChildren()
        
        let gameOverLabel = SKLabelNode(fontNamed: "Arial")
        
        gameOverLabel.text = "Game Over"
        
        gameOverLabel.fontColor = UIColor.whiteColor()
        
        gameOverLabel.fontSize = 40
        
        gameOverLabel.position = CGPointMake(self.size.width/2, self.size.height/2)
        
        addChild(gameOverLabel)
    }
    
    
    
    func didBeginContact(contact: SKPhysicsContact) {
        let bodyA = contact.bodyA
        let bodyB = contact.bodyB
        
        let contactA = bodyA.categoryBitMask
        let contactB = bodyB.categoryBitMask
        
      
        switch contactA {
            
        case Bodytype.Meteor:
            
            switch contactB {
                
            case Bodytype.Meteor:
                break
                
            case Bodytype.Bullet:
                if let bodyBNode = contact.bodyB.node as? SKSpriteNode, bodyANode = contact.bodyA.node as? Enemy {
                    bulletHitMeteor(bodyBNode, meteor: bodyANode)
                }
                
            case Bodytype.Hero:
                if let bodyBNode = contact.bodyB.node as? SKSpriteNode, bodyANode = contact.bodyA.node as? Enemy {
                    heroHitMeteor(bodyBNode, meteor: bodyANode)
                }
                
            default:
                break
            }
            
        case Bodytype.Bullet:
            
            switch contactB {
                
            case Bodytype.Meteor:
                if let bodyANode = contact.bodyA.node as? SKSpriteNode, bodyBNode = contact.bodyB.node as? Enemy {
                    bulletHitMeteor(bodyANode, meteor: bodyBNode)
                }
                
            case Bodytype.Bullet:
                break     
                
            case Bodytype.Hero:
                break             
                
            default:
                break
            }
            
        case Bodytype.Hero:       
            
            switch contactB {
                
            case Bodytype.Meteor:
                if let bodyANode = contact.bodyA.node as? SKSpriteNode, bodyBNode = contact.bodyB.node as? Enemy {
                    heroHitMeteor(bodyANode, meteor: bodyBNode)
                }           
                
            case Bodytype.Bullet:
                break     
                
            case Bodytype.Hero:
                break       
                
            default:
                break
            }
            
        default:
            break
        }
        
    }

    func explodeMeteor(meteor: Enemy){
        
        var tokens: [Token] = []
        
        for var i = 1; i<arc4random(); i++
        {
            tokens.append(Token(imageNamed: "token"))
        }
    
       
        
        for token in tokens{
            
            let randomExplosionX = (random() * (1000 + size.width)) - size.width
            
            let randomExplosionY = (random() * (1000 + size.height)) - size.width
            
            
            let moveExplosion: SKAction
            moveExplosion = SKAction.moveTo(CGPoint(x: randomExplosionX, y: randomExplosionY), duration: NSTimeInterval(40))
            
            token.runAction(SKAction.sequence([moveExplosion, SKAction.removeFromParent()]))
        
            
            token.size = CGSize(width: 40, height: 40)
            token.position = CGPointMake(meteor.position.x, meteor.position.y)
            
            addChild(token)
            
            
        }
        
    }
    
    
}







